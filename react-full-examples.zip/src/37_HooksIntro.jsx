import React from "react";
export default function HooksIntro(){return<p>Hooks let you use state and lifecycle without classes.</p>;}