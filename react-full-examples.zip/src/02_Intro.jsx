import React from "react";
export default function Intro() { return <p>React is a JavaScript library for building UIs.</p>; }