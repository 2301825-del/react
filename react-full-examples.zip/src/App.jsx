import React from "react";
import Home from "./01_Home";
// import Intro from "./02_Intro";
// import GetStarted from "./03_GetStarted";
// ... other imports, uncomment to test examples
export default function App(){return <Home/>;}