import React from "react";
export default function EventsExample() { return <button onClick={() => alert("Clicked!")}>Click</button>; }