import React from "react";
import styles from "./styles.module.css";
export default function CSSModules() { return <h2 className={styles.green}>Styled with CSS Module</h2>; }