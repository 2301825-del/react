import React from "react";
export default function JSXIf() { const x = 5; return <h2>{x > 10 ? "Greater" : "Smaller"}</h2>; }