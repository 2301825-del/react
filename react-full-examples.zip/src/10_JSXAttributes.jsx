import React from "react";
export default function JSXAttributes() { return <img src="https://via.placeholder.com/100" alt="demo" />; }