import React from "react";
import "./style.scss";
export default function SassExample(){return<h2 className="sass">Styled with Sass</h2>;}