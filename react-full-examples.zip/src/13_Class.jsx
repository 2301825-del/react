import React, { Component } from "react";
export default class ClassExample extends Component { render() { return <h2>Hello from Class Component</h2>; } }