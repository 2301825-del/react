import React from "react";
export default function RenderHTML() { return <div><h2>Rendered HTML</h2><p>This is JSX rendering HTML.</p></div>; }