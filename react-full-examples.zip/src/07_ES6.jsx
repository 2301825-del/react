import React from "react";
const arrow = () => "Hello ES6";
export default function ES6Example() { return <p>{arrow()}</p>; }