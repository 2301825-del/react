import React from "react";
export default function JSXIntro() { return <h2>JSX allows writing HTML inside JavaScript</h2>; }