import React from "react";
export default function GetStarted() { return <p>Get started with React by creating a project.</p>; }