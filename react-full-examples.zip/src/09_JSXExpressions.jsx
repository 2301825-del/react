import React from "react";
export default function JSXExpressions() { const name = "John"; return <h2>Hello {name}</h2>; }