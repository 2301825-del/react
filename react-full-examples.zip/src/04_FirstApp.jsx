import React from "react";
export default function FirstApp() { return <h2>My First React App</h2>; }