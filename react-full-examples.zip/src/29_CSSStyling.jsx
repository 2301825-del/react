import React from "react";
import "./styles.css";
export default function CSSStyling() { return <h2 className="red">Styled with CSS</h2>; }