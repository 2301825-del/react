import React from "react";
const style={color:"blue",fontSize:"20px"};
export default function CSSinJS() { return <h2 style={style}>Styled with inline JS</h2>; }